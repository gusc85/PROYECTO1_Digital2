/*
 * File:   main_ultra.c
 * Author: cuyog
 *
 * Created on 23 de agosto de 2023, 12:04
 */

//#include <xc.h>
//#include <stdint.h>
//#include <pic16f887.h>
//
//#define _XTAL_FREQ 500000
//#define LED_PIN     RB1 // Pin del LED
//#define TRIGPin     RA3 // Pin del TRIGGER
//#define ECHOPin     RA4 // Pin del ECHO
//
//// Definiciones de pines
//void ultrasonic_init(void){
//    TRIGPin = 0;
//    ECHOPin = 1;
//}
//
//double ultrasonic_measure_distance(void)
//{
//    double distancia_final;
//    uint16_t contador = 0;
//
//    TRIGPin = 1;
//    __delay_us(10);
//    TRIGPin = 0;
//    while (ECHOPin == 0);
//    while (ECHOPin == 1){
//        contador++;
//    }
//    distancia_final = 16*(contador)/10.5;
//
//    return distancia_final;
//}
//
//void main() {
//    // Configuraci�n de pines
//    TRISB1 = 0; // Configura RB1 como salida para el LED
//    ultrasonic_init(); // Inicializa el sensor ultras�nico
//
//    while(1) {
//        double distance = ultrasonic_measure_distance(); // Mide la distancia con el sensor
//
//        if(distance < 50) { // Si la distancia es menor a 50 unidades (ajusta este valor seg�n tus necesidades)
//            LED_PIN = 1; // Enciende el LED en RB1
//        } else {
//            LED_PIN = 0; // Apaga el LED en RB1
//        }
//    }
//}




//
//#include <xc.h>
//#include <stdint.h>
//#include <pic16f887.h>
//#include "lcd.h"
//
//#define _XTAL_FREQ 500000
//
//
//float distancia;
//float tiempo;
//
//#define TRIG RB1
//#define ECHO RB0
//
//uint16_t contador = 0;
//
//
//void main()
//{
//// ULTRAS�NICO
//    Lcd_Init();
//    Lcd_Set_Cursor(1, 1); // Posici?n en la primera l?nea
//    Lcd_Write_String("LECTURA DEL SENSOR"); // Borra la l?nea
//    __delay_ms(1000);
//    Lcd_Set_Cursor(2, 1); // Posici?n despu?s de "Contador: "
//    Lcd_Write_String("OBJETO DETECTADO"); // Borra la l?nea
//    
//
//while(1)
//{
//
//TRIG == 1;
//__delay_us(10);                       
//TRIG == 0;
//__delay_us(10); 
//    while (ECHO == 0);
//    while (ECHO == 1){
//        contador++;
//    }
//    distancia= 16*(contador)/10.5;
//    
//    Lcd_Set_Cursor(1, 1); // Posici?n en la primera l?nea
//    Lcd_Write_String("DISTANCIA:"); // Borra la l?nea
//    __delay_ms(1000);
//    Lcd_Set_Cursor(2, 2); // Posici?n despu?s de "Contador: "
//    Lcd_Write_String("OBJETO DETECTADO"); // Borra la l?nea
//}
//}

#pragma config FOSC = INTRC_NOCLKOUT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config MCLRE = OFF
#pragma config CP = OFF
#pragma config CPD = OFF
#pragma config BOREN = OFF
#pragma config IESO = OFF
#pragma config FCMEN = OFF
#pragma config LVP = OFF
#pragma config BOR4V = BOR40V
#pragma config WRT = OFF

#include <xc.h>
#include <stdint.h>
#include <stdio.h>

#include "LCD.h"

void setup(void);
uint8_t bcd_to_decimal(uint8_t bdc);
void pantalla(void);
void ADC_Init();
uint16_t ADC_Read(uint8_t channel);

#define _XTAL_FREQ 1000000
#define LIGHT_SENSOR_PIN    RA2
#define LED_PIN             RB0

uint8_t contador ;

void __interrupt() isr(void)
{
}

void main() {
    setup();

    uint8_t contador = 0;
    uint8_t objeto_detectado = 0;
    uint8_t contador2 = 0;
    uint8_t objeto_detectado2 = 0;
    uint8_t contQ1 = 0;

    while(1) {
        pantalla();

        if (RC0 == 1) {
            if (!objeto_detectado) {
                contador++;
                objeto_detectado = 1;
                __delay_ms(500);
            }
        } else {
            objeto_detectado = 0;
        }

        if (RC1 == 1) {
            if (!objeto_detectado2) {
                contador2++;
                objeto_detectado2 = 1;
                __delay_ms(500);
            }
        } else {
            objeto_detectado2 = 0;
        }

        float resultado = contador + (contador2 * 0.5);
        
        if (contador2 >= 1) {
            RA0 = 1;
        } else {
            RA0 = 0;
        }

        if (contador2 >= 2) {
            RA1 = 1;
        } else {
            RA1 = 0;
        }

        if (contador2 >= 3) {
            RA2 = 1;
        } else {
            RA2 = 0;
        }
        if (contador2 >= 5) {
            RA3 = 1;
        } else {
            RA3 = 0;
        }

        char contador_str[4];
        sprintf(contador_str, "%d", contador);

        char contador2_str[4];
        sprintf(contador2_str, "%d", contador2);

        char resultado_str[10];
        sprintf(resultado_str, "%.2f", resultado);

        Lcd_Set_Cursor(1, 1);
        Lcd_Write_String("Q1");
        Lcd_Set_Cursor(2, 1);
        Lcd_Write_String(contador_str);

        Lcd_Set_Cursor(1, 5);
        Lcd_Write_String("Q0.50");
        Lcd_Set_Cursor(2, 5);
        Lcd_Write_String(contador2_str);

        Lcd_Set_Cursor(1, 12);
        Lcd_Write_String("Total");
        Lcd_Set_Cursor(2, 12);
        Lcd_Write_String(resultado_str);

        TRISAbits.TRISA2 = 1;
        TRISB = 0x00;
        ADC_Init();

        while(1) {
            ADCON0bits.GO_nDONE = 1;

            while (ADCON0bits.GO_nDONE);

            uint16_t adcValue = (ADRESH << 8) + ADRESL;

            uint16_t valorLimite = 1023 * 0.5;

            if (adcValue > valorLimite) {
                LED_PIN = 1;
            } 
            else {
                LED_PIN = 0;
            }
        }
    }

    return;
}

void ADC_Init() {
    ADCON0 = 0b01000001;
    ADCON1 = 0b00000000;
}


