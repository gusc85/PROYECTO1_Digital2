// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF         // Low Voltage Programming Enable bit (RB3/PGM pin has PGM function, low voltage programming enabled)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)
#include <xc.h> // Debes incluir la librer�a xc.h

// Configuraci�n de los registros ADC
__CONFIG(FOSC_HS & WDTE_OFF & PWRTE_OFF & MCLRE_OFF & CP_OFF & CPD_OFF & BOREN_OFF & IESO_OFF & FCMEN_OFF & LVP_OFF & BOR4V_BOR40V & WRT_OFF);

#define _XTAL_FREQ 8000000 // Frecuencia de oscilador, ajusta esto a tu configuraci�n

// Definiciones de pines
#define LDR_PIN   AN0  // Pin del sensor LDR (entrada anal�gica)
#define MOTOR_PIN RB0  // Pin de control del motor DC

void main() {
    TRISB0 = 0; // Configurar el pin del motor como salida
    MOTOR_PIN = 0; // Apagar el motor inicialmente

    // Configurar el pin del sensor LDR como entrada anal�gica
    TRISA0 = 1;

    // Configurar el m�dulo ADC
    ADCON0 = 0x01; // Seleccionar AN0 como entrada anal�gica
    ADCON1 = 0x80; // Configurar el reloj de conversi�n a Fosc/2
//    ADCON2 = 0x88; // Resultado justificado a la derecha, Tad = 2Tosc

    while (1) {
        // Realizar una conversi�n ADC
        GO_nDONE = 1; // Iniciar la conversi�n

        while (GO_nDONE); // Esperar a que la conversi�n termine

        // Leer el valor ADC
        unsigned int adcValue = ((unsigned int)ADRESH << 8) | ADRESL;

        // Si la luz es baja (valor ADC alto), encender el motor
        if (adcValue > 512) { // Ajusta este umbral seg�n tu sensor LDR
            MOTOR_PIN = 1; // Encender el motor
        } else {
            MOTOR_PIN = 0; // Apagar el motor si la luz es alta
        }
        while(1) {
                
        // Env?a el valor del sensor de luz al otro PIC a trav?s de I2C
        I2C_Master_Start(); // Inicia la comunicaci?n I2C
        I2C_Master_Write(0x50); // Direcci?n del dispositivo esclavo (segundo PIC)
        I2C_Master_Write(LDR_PIN >> 8); // Env?a byte m?s significativo
        I2C_Master_Write(LDR_PIN & 0xFF); // Env?a byte menos significativo
        I2C_Master_Stop(); // Detiene la comunicaci?n I2C
        }
        
        }
    }
